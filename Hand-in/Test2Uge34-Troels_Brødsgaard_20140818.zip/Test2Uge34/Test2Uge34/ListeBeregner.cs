﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2Uge34
{
    class ListeBeregner
    {
        public static double Gennemsnit(List<double> talliste)
        {
            double average = 0;
            double sum = 0;
            double numbers = 0;

            foreach (double number in talliste)
            {
                sum += number;
                numbers++;
            }

            average = sum / numbers;

            return average;
        }

        public static double FindNextSmallestNumber(List<double> numbers)
        {
            double smallestNumber = findSmallestNumber(numbers);
            List<double> biggerNumbers = numbers;
            biggerNumbers.Remove(smallestNumber);
            double nextSmallestNumber = findSmallestNumber(biggerNumbers);

            return nextSmallestNumber;
        }

        // TODO: Not yet implemented
        public static double CalculateLowerQuartile(List<double> numbers)
        {
            // how many numbers are needed to calculate quartile?
            // which are those numbers? use findSmallestNumber, always cutting the lowest from the list

            throw new NotImplementedException();
        }

        private static double findSmallestNumber(List<double> numbers)
        {
            double smallestNumber = numbers[0];

            for (int i = 1; i < numbers.Count; i++)
            {
                if (numbers[i] < smallestNumber)
                {
                    smallestNumber = numbers[i];
                }
            }

            return smallestNumber;
        }
    }
}
