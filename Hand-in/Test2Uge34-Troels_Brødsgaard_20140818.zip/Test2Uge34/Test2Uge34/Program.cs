﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2Uge34
{
    class Program
    {
        static void Main(string[] args)
        {
            List<double> numbers = new List<double>() { -10, 1, 10, 200, 7.4 };

            // should be 4.1
            Console.WriteLine("Average " + ListeBeregner.Gennemsnit(numbers));
            Console.WriteLine("Next smallest number " + ListeBeregner.FindNextSmallestNumber(numbers));

            Console.ReadLine();
        }
    }
}
